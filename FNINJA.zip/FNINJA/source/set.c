#include "./include/common.h"
#include "./include/main.h"


int page_setting(int *d,int *ti){
	int page=9;
	clrmous(MouseX,MouseY);
	delay(100);
	page_setting_screen(); //��ʼ��Ϸ�����汳������ 
	
	while(page==9){
		mou_pos(&MouseX,&MouseY,&press);
		
		if(mouse_press(20,20,100,60)==1){
			page=0;
		}
		
		if(mouse_press(180,120,240,180)==1){
			*d=0;
			setfillstyle(SOLID_FILL,BLACK);
			bar(190,390,410,510);
			puthz(200,400,"�Ѷ�����Ϊ��",24,20,WHITE);
		}			
		if(mouse_press(320,120,380,180)==1){
			*d=1;
			setfillstyle(SOLID_FILL,BLACK);
			bar(190,390,410,510);
			puthz(200,400,"�Ѷ�����Ϊ��",24,20,WHITE);
		}			
		if(mouse_press(460,120,520,180)==1){
			*d=2;
			setfillstyle(SOLID_FILL,BLACK);
			bar(190,390,410,510);
			puthz(200,400,"�Ѷ�����Ϊ��",24,20,WHITE);
		}	
				
		if(mouse_press(180,250,240,310)==1){
			*ti=30;
			setfillstyle(SOLID_FILL,BLACK);
			bar(190,390,410,510);
			puthz(200,400,"��ģʽʱ����Ϊ��ʮ��",24,20,WHITE);
		}			
		if(mouse_press(320,250,380,310)==1){
			*ti=60;
			setfillstyle(SOLID_FILL,BLACK);
			bar(190,390,410,510);
			puthz(200,400,"��ģʽʱ����Ϊ��ʮ��",24,20,WHITE);
		}			
		if(mouse_press(460,250,520,310)==1){
			*ti=90;
			setfillstyle(SOLID_FILL,BLACK);
			bar(190,390,410,510);
			puthz(200,400,"��ģʽʱ����Ϊ��ʮ��",24,20,WHITE);
		}							
	}
	return page;
}


void page_setting_screen(){
	cleardevice();
	setbkcolor(BLACK);
	setfillstyle(SOLID_FILL,LIGHTBLUE);
	bar(20,20,100,60);
	bar(40,100,140,200);	
	bar(40,230,140,330);
	setfillstyle(SOLID_FILL,LIGHTRED);
	bar(200,30,420,70);
	setfillstyle(SOLID_FILL,LIGHTGRAY);
	bar(180,120,240,180);
	bar(320,120,380,180);
	bar(460,120,520,180);	
	bar(180,250,240,310);
	bar(320,250,380,310);
	bar(460,250,520,310);
	
	puthz(40,25,"����",16,30,WHITE);
	puthz(270,35,"����",24,50,WHITE);
	puthz(40,120,"�Ѷ�",48,50,WHITE);	
	puthz(180,120,"��",48,50,RED);
	puthz(320,120,"��",48,50,RED);
	puthz(460,120,"��",48,50,RED);	
	
	puthz(40,250,"ʱ��",48,50,WHITE);	
	puthz(190,260,"��ʮ",24,20,RED);
	puthz(330,260,"��ʮ",24,20,RED);
	puthz(470,260,"��ʮ",24,20,RED);


}

