#include "./include/common.h"
#include "./include/main.h"

void show_apple(int xd,int yd)//��ƻ��
{   
	setcolor(RED);
	setfillstyle(SOLID_FILL,RED);
	sector(xd,yd,180,360,20,20);
	setfillstyle(SOLID_FILL,RED);
	sector(xd-10,yd,0,180,10,10);
	setfillstyle(SOLID_FILL,RED);
	sector(xd+10,yd,0,180,10,10);
	
	setcolor(GREEN);
	moveto(xd-2,yd-7);
	lineto(xd-2,yd-22);
	lineto(xd+2,yd-22);
	lineto(xd+2,yd-7);
	lineto(xd,yd);
	lineto(xd-2,yd-7);	 
	setfillstyle(SOLID_FILL,GREEN);
	floodfill(xd,yd-10,GREEN);
}

void show_pineapple(int xd,int yd)//������ 
{
	setcolor(GREEN);
	moveto(xd,yd);
	lineto(xd-4,yd-7);
	lineto(xd+4,yd-7);
	lineto(xd,yd);
	setfillstyle(SOLID_FILL,GREEN);
	floodfill(xd,yd-2,GREEN);
	
	setcolor(YELLOW);
	line(xd-8,yd,xd+8,yd);
	line(xd-12,yd+4,xd-12,yd+26);
	line(xd+12,yd+4,xd+12,yd+26);
	line(xd-8,yd+30,xd+8,yd+30);
	setfillstyle(SOLID_FILL,YELLOW);
	sector(xd-8,yd+4,90,180,4,4);
	sector(xd+8,yd+4,0,90,4,4);
	sector(xd-8,yd+26,180,270,4,4);
	sector(xd+8,yd+26,270,360,4,4);			
	floodfill(xd,yd+5,YELLOW); 
}

void show_lemon(int xd,int yd)	//������ 
{
	setcolor(YELLOW);	
	setfillstyle(SOLID_FILL,YELLOW);
	sector(xd,yd,0,360,20,15);
	setfillstyle(SOLID_FILL,GREEN);
	sector(xd,yd,0,360,2,2);	
}

void show_grape(int xd,int yd)	//������ 
{
	setcolor(CYAN);
	setfillstyle(SOLID_FILL,CYAN);
	sector(xd,yd,0,360,15,15); 
}

void show_pomegranate(int xd,int yd)  //��ʯ��
{
	setcolor(LIGHTMAGENTA);
	setfillstyle(SOLID_FILL,LIGHTMAGENTA);
	sector(xd,yd+12,90,270,12,12);
	sector(xd+4,yd+12,270,360,12,12);
	sector(xd+4,yd+12,0,90,12,12);
	bar(xd,yd,xd+4,yd+24);
	
	setfillstyle(SOLID_FILL,RED);
	bar(xd,yd-7,xd+4,yd);
	
	setcolor(LIGHTGREEN);
	moveto(xd,yd-7);
	lineto(xd-7,yd-7);
	lineto(xd,yd-2);
	lineto(xd,yd-7);
	setfillstyle(SOLID_FILL,GREEN);
	floodfill(xd-1,yd-6,LIGHTGREEN);	
	
	setcolor(LIGHTGREEN);
	moveto(xd,yd-7);
	lineto(xd,yd-14);
	lineto(xd+2,yd-9);
	lineto(xd+4,yd-14);
	lineto(xd+4,yd-7);
	lineto(xd,yd-7);
	setfillstyle(SOLID_FILL,GREEN);
	floodfill(xd+2,yd-8,LIGHTGREEN);	
	
	setcolor(LIGHTGREEN);
	moveto(xd+4,yd-7);
	lineto(xd+11,yd-7);
	lineto(xd+4,yd-2);
	lineto(xd+4,yd-7);
	setfillstyle(SOLID_FILL,GREEN);
	floodfill(xd+5,yd-6,LIGHTGREEN);				 	
}

void show_banana(int xd,int yd)
{
	setcolor(YELLOW);
	arc(xd,yd,270,0,34);
	arc(xd,yd,270,0,20);
	moveto(xd,yd+20);
	lineto(xd-5,yd+27);
	lineto(xd,yd+34);
	moveto(xd+20,yd);
	lineto(xd+25,yd-2);
	lineto(xd+25,yd-8);
	lineto(xd+29,yd-8);
	lineto(xd+29,yd-2);
	lineto(xd+34,yd);

	setfillstyle(SOLID_FILL,YELLOW);
	floodfill(xd+27,yd-2,YELLOW);	
}

void show_red_banana(int xd,int yd)
{
	setcolor(LIGHTRED);
	arc(xd,yd,270,0,34);
	arc(xd,yd,270,0,20);
	moveto(xd,yd+20);
	lineto(xd-5,yd+27);
	lineto(xd,yd+34);
	moveto(xd+20,yd);
	lineto(xd+25,yd-2);
	lineto(xd+25,yd-8);
	lineto(xd+29,yd-8);
	lineto(xd+29,yd-2);
	lineto(xd+34,yd);

	setfillstyle(SOLID_FILL,LIGHTRED);
	floodfill(xd+27,yd-2,LIGHTRED);	
}

void show_blue_banana(int xd,int yd)
{
	setcolor(LIGHTBLUE);
	arc(xd,yd,270,0,34);
	arc(xd,yd,270,0,20);
	moveto(xd,yd+20);
	lineto(xd-5,yd+27);
	lineto(xd,yd+34);
	moveto(xd+20,yd);
	lineto(xd+25,yd-2);
	lineto(xd+25,yd-8);
	lineto(xd+29,yd-8);
	lineto(xd+29,yd-2);
	lineto(xd+34,yd);

	setfillstyle(SOLID_FILL,LIGHTBLUE);
	floodfill(xd+27,yd-2,LIGHTBLUE);	
}

void show_green_banana(int xd,int yd)
{
	setcolor(LIGHTGREEN);
	arc(xd,yd,270,0,34);
	arc(xd,yd,270,0,20);
	moveto(xd,yd+20);
	lineto(xd-5,yd+27);
	lineto(xd,yd+34);
	moveto(xd+20,yd);
	lineto(xd+25,yd-2);
	lineto(xd+25,yd-8);
	lineto(xd+29,yd-8);
	lineto(xd+29,yd-2);
	lineto(xd+34,yd);

	setfillstyle(SOLID_FILL,LIGHTGREEN);
	floodfill(xd+27,yd-2,LIGHTGREEN);	
}
void show_bomb(int xd,int yd)
{
	setcolor(BLUE);
	setfillstyle(SOLID_FILL,BLUE); 
	sector(xd,yd,120,360,16,16);
	sector(xd,yd,0,60,16,16);
	
	setcolor(BLUE);
	moveto(xd,yd);
	lineto(xd-8,yd-13);
	lineto(xd-8,yd-17);
	lineto(xd+8,yd-17);
	lineto(xd+8,yd-13);
	lineto(xd,yd);
	setfillstyle(SOLID_FILL,BLUE);
	floodfill(xd,yd-10,BLUE);
		
	setcolor(YELLOW);
	moveto(xd-4,yd-17);
	lineto(xd,yd-27);
	lineto(xd+4,yd-17);
	lineto(xd-4,yd-17);
	setfillstyle(SOLID_FILL,YELLOW);
	floodfill(xd,yd-18,YELLOW);
}

//��ˮ����Ƭ 
void show_apple_pieces(int xd,int yd)	//ƻ����Ƭ 
{
	setcolor(RED);
	setfillstyle(SOLID_FILL,RED);
	sector(xd+15,yd,0,180,10,10);
	sector(xd-6,yd+4,90,270,10,10);
	sector(xd+20,yd+2,270,360,20,20);
	sector(xd+14,yd+12,210,300,20,20);
	
	setcolor(GREEN);
	moveto(xd,yd-5);
	lineto(xd-2,yd-11);
	lineto(xd-2,yd-26);
	lineto(xd+2,yd-26);
	lineto(xd+2,yd-11);
	lineto(xd,yd-5);
	setfillstyle(SOLID_FILL,GREEN);
	floodfill(xd,yd-10,GREEN);
}

void show_banana_pieces(int xd,int yd)	//�㽶��Ƭ 
{
	setcolor(YELLOW);
	setfillstyle(SOLID_FILL,YELLOW);
	bar(xd+10,yd-4,xd+44,yd+10);
	bar(xd-18,yd+4,xd-4,yd+38);
	
	setcolor(YELLOW);
	moveto(xd+10,yd+14);
	lineto(xd+24,yd+14);
	lineto(xd+17,yd+19);
	lineto(xd+10,yd+14);
	setfillstyle(SOLID_FILL,YELLOW);
	floodfill(xd+17,yd+15,YELLOW);
	
	setcolor(YELLOW);
	moveto(xd+30,yd+15);
	lineto(xd+32,yd+20);
	lineto(xd+38,yd+20);
	lineto(xd+38,yd+24);
	lineto(xd+32,yd+24);
	lineto(xd+30,yd+29);
	lineto(xd+30,yd+15);
	setfillstyle(SOLID_FILL,YELLOW);
	floodfill(xd+35,yd+22,YELLOW);
}
void show_red_banana_pieces(int xd,int yd)	//��ɫ�㽶��Ƭ 
{
	setcolor(LIGHTRED);
	setfillstyle(SOLID_FILL,LIGHTRED);
	bar(xd+10,yd-4,xd+44,yd+10);
	bar(xd-18,yd+4,xd-4,yd+38);
	
	setcolor(LIGHTRED);
	moveto(xd+10,yd+14);
	lineto(xd+24,yd+14);
	lineto(xd+17,yd+19);
	lineto(xd+10,yd+14);
	setfillstyle(SOLID_FILL,LIGHTRED);
	floodfill(xd+17,yd+15,LIGHTRED);
	
	setcolor(LIGHTRED);
	moveto(xd+30,yd+15);
	lineto(xd+32,yd+20);
	lineto(xd+38,yd+20);
	lineto(xd+38,yd+24);
	lineto(xd+32,yd+24);
	lineto(xd+30,yd+29);
	lineto(xd+30,yd+15);
	setfillstyle(SOLID_FILL,LIGHTRED);
	floodfill(xd+35,yd+22,LIGHTRED);
}
void show_blue_banana_pieces(int xd,int yd)	//��ɫ�㽶��Ƭ 
{
	setcolor(LIGHTBLUE);
	setfillstyle(SOLID_FILL,LIGHTBLUE);
	bar(xd+10,yd-4,xd+44,yd+10);
	bar(xd-18,yd+4,xd-4,yd+38);
	
	setcolor(LIGHTBLUE);
	moveto(xd+10,yd+14);
	lineto(xd+24,yd+14);
	lineto(xd+17,yd+19);
	lineto(xd+10,yd+14);
	setfillstyle(SOLID_FILL,LIGHTBLUE);
	floodfill(xd+17,yd+15,LIGHTBLUE);
	
	setcolor(LIGHTBLUE);
	moveto(xd+30,yd+15);
	lineto(xd+32,yd+20);
	lineto(xd+38,yd+20);
	lineto(xd+38,yd+24);
	lineto(xd+32,yd+24);
	lineto(xd+30,yd+29);
	lineto(xd+30,yd+15);
	setfillstyle(SOLID_FILL,LIGHTBLUE);
	floodfill(xd+35,yd+22,LIGHTBLUE);
}
void show_green_banana_pieces(int xd,int yd)	//��ɫ�㽶��Ƭ 
{
	setcolor(LIGHTGREEN);
	setfillstyle(SOLID_FILL,LIGHTGREEN);
	bar(xd+10,yd-4,xd+44,yd+10);
	bar(xd-18,yd+4,xd-4,yd+38);
	
	setcolor(LIGHTGREEN);
	moveto(xd+10,yd+14);
	lineto(xd+24,yd+14);
	lineto(xd+17,yd+19);
	lineto(xd+10,yd+14);
	setfillstyle(SOLID_FILL,LIGHTGREEN);
	floodfill(xd+17,yd+15,LIGHTGREEN);
	
	setcolor(LIGHTGREEN);
	moveto(xd+30,yd+15);
	lineto(xd+32,yd+20);
	lineto(xd+38,yd+20);
	lineto(xd+38,yd+24);
	lineto(xd+32,yd+24);
	lineto(xd+30,yd+29);
	lineto(xd+30,yd+15);
	setfillstyle(SOLID_FILL,LIGHTGREEN);
	floodfill(xd+35,yd+22,LIGHTGREEN);
}
void show_grape_pieces(int xd,int yd)	//������Ƭ 
{
	setcolor(CYAN);
	setfillstyle(SOLID_FILL,CYAN);
	sector(xd,yd+8,180,360,15,15);
	sector(xd-12,yd,30,210,15,15);
}
void show_lemon_pieces(int xd,int yd)	//������Ƭ 
{
	setcolor(YELLOW);
	setfillstyle(SOLID_FILL,YELLOW);
	sector(xd,yd+12,180,360,20,15);
	sector(xd-10,yd,30,210,20,15);
	
	setcolor(GREEN);
	setfillstyle(SOLID_FILL,GREEN);
	sector(xd,yd+12,180,360,2,2);
	sector(xd-10,yd,30,210,2,2);
}
void show_pineapple_pieces(int xd,int yd)	//������Ƭ 
{
	setcolor(GREEN);
	moveto(xd,yd-4);
	lineto(xd+4,yd-11);
	lineto(xd-4,yd-11);
	lineto(xd,yd-4);
	setfillstyle(SOLID_FILL,GREEN);
	floodfill(xd,yd-5,GREEN);
	
	setcolor(YELLOW);
	arc(xd-14,yd+8,90,180,4);
	moveto(xd-14,yd+4);
	lineto(xd+2,yd+4);
	lineto(xd-6,yd+19);
	lineto(xd-18,yd+8);
	setfillstyle(SOLID_FILL,YELLOW);
	floodfill(xd-7,yd+8,YELLOW);
	
	setcolor(YELLOW);
	arc(xd+20,yd,0,90,4);
	moveto(xd+24,yd);
	lineto(xd+24,yd+22);
	lineto(xd+12,yd+11);
	lineto(xd+20,yd-4);
	setfillstyle(SOLID_FILL,YELLOW);
	floodfill(xd+20,yd,YELLOW);
	
	setcolor(YELLOW);
	arc(xd+18,yd+50,270,360,4);
	moveto(xd+18,yd+54);
	lineto(xd+2,yd+54);
	lineto(xd+10,yd+39);
	lineto(xd+22,yd+50);
	setfillstyle(SOLID_FILL,YELLOW);
	floodfill(xd+18,yd+50,YELLOW);
	
	setcolor(YELLOW);
	arc(xd-18,yd+50,180,270,4);
	moveto(xd-22,yd+50);
	lineto(xd-22,yd+28);
	lineto(xd-10,yd+39);
	lineto(xd-18,yd+54);
	setfillstyle(SOLID_FILL,YELLOW);
	floodfill(xd-18,yd+50,YELLOW);
}
void show_pomegranate_pieces(int xd,int yd)	//ʯ����Ƭ 
{
	setcolor(LIGHTMAGENTA);
	setfillstyle(SOLID_FILL,LIGHTMAGENTA);
	sector(xd+12,yd,270,360,12,12);
	sector(xd-15,yd,210,300,12,12);
	sector(xd-12,yd+24,135,225,12,12);
	sector(xd+6,yd+24,300,360,12,12);
	sector(xd+6,yd+24,0,30,12,12);
	
	setfillstyle(SOLID_FILL,LIGHTMAGENTA);
	bar(xd+2,yd+4,xd+6,yd+16);
	bar(xd-8,yd+18,xd-4,yd+30);
	
	setfillstyle(SOLID_FILL,RED);
	bar(xd-6,yd-11,xd-2,yd-4);
	
	setcolor(LIGHTGREEN);
	moveto(xd-6,yd-11);
	lineto(xd-13,yd-11);
	lineto(xd-6,yd-6);
	lineto(xd-6,yd-11);
	setfillstyle(SOLID_FILL,GREEN);
	floodfill(xd-7,yd-10,LIGHTGREEN);
	
	setcolor(LIGHTGREEN);
	moveto(xd-6,yd-11);
	lineto(xd-6,yd-18);
	lineto(xd-4,yd-13);
	lineto(xd-2,yd-18);
	lineto(xd-2,yd-11);
	lineto(xd-6,yd-11);
	setfillstyle(SOLID_FILL,GREEN);
	floodfill(xd-4,yd-12,LIGHTGREEN);
	
	setcolor(LIGHTGREEN);
	moveto(xd-2,yd-11);
	lineto(xd+5,yd-11);
	lineto(xd-2,yd-6);
	lineto(xd-2,yd-11);
	setfillstyle(SOLID_FILL,GREEN);
	floodfill(xd-1,yd-10,LIGHTGREEN);
}

void show_bomb_pieces(int xd, int yd) //ը����Ƭ
{
	setcolor(YELLOW);
	moveto(xd,yd+45);
	lineto(xd-9,yd+9);
	lineto(xd-45,yd);
	lineto(xd-9,yd-9);
	lineto(xd,yd-45);
	lineto(xd+9,yd-9);
	lineto(xd+45,yd);
	lineto(xd+9,yd+9);
	lineto(xd,yd+45);
	setfillstyle(SOLID_FILL,YELLOW);
	floodfill(xd,yd,YELLOW);
}

void cover_apple(int xd,int yd)
{
	setfillstyle(SOLID_FILL,BLACK);
	bar(xd-20,yd-23,xd+20,yd+20);
}
void cover_banana(int xd,int yd)
{
	setfillstyle(SOLID_FILL,BLACK);
	bar(xd-5,yd-8,xd+34,yd+34);
}
void cover_grape(int xd,int yd)
{
	setfillstyle(SOLID_FILL,BLACK);
	bar(xd-15,yd-15,xd+15,yd+15);
}
void cover_lemon(int xd,int yd)
{
	setfillstyle(SOLID_FILL,BLACK);
	bar(xd-20,yd-15,xd+20,yd+15); 
}
void cover_pineapple(int xd,int yd)
{
	setfillstyle(SOLID_FILL,BLACK);
	bar(xd-12,yd-7,xd+12,yd+30);
}
void cover_pomegranate(int xd,int yd)
{
	setfillstyle(SOLID_FILL,BLACK);
	bar(xd-12,yd-14,xd+16,yd+24);
}
void cover_bomb(int xd,int yd)
{
	setfillstyle(SOLID_FILL,BLACK);
	bar(xd-16,yd-27,xd+16,yd+16);
}

//������Ƭ
void cover_apple_pieces(int xd,int yd)
{
	setfillstyle(SOLID_FILL,BLACK);
	bar(xd-16,yd-26,xd+40,yd+32);	
}
void cover_banana_pieces(int xd,int yd)
{
	setfillstyle(SOLID_FILL,BLACK);
	bar(xd-18,yd-4,xd+44,yd+38);	
}
void cover_grape_pieces(int xd,int yd)
{
	setfillstyle(SOLID_FILL,BLACK);
	bar(xd-28,yd-15,xd+15,yd+24);
}
void cover_pineapple_pieces(int xd,int yd)
{
	setfillstyle(SOLID_FILL,BLACK);
	bar(xd-22,yd-11,xd+24,yd+54);
}
void cover_pomegranate_pieces(int xd,int yd)
{
	setfillstyle(SOLID_FILL,BLACK);
	bar(xd-26,yd-18,xd+24,yd+35);
}
void cover_lemon_pieces(int xd,int yd)
{
	setfillstyle(SOLID_FILL,BLACK);
	bar(xd-32,yd-15,xd+20,yd+27);
}
void cover_bomb_pieces(int xd,int yd)
{

	setfillstyle(SOLID_FILL,BLACK);
	bar(xd-45,yd-45,xd+45,yd+45);
}

void draw_hori_circles(int x, int y,int x_end,int color)
{
	int x1=x,y1=y,r=6;
	setcolor(color);
	//setlinestyle
	setlinestyle(0,0,1);
	while(x1< x_end)
	{
		circle(x1+2*r,y1+r,r);
		circle(x1+2*r,y1+3*r,r);
		circle(x1+1*r,y1+2*r,r);
		circle(x1+3*r,y1+2*r,r);
		x1+=4*r;
	}

}
void draw_verti_circles(int x, int y,int color)
{
	int x1=x,y1=y,r=6;
	setcolor(color);
	setlinestyle(0,0,1);
	while(y1<490)
	{
		circle(x1+1*r,y1+2*r,r);
		circle(x1+3*r,y1+2*r,r);
		circle(x1+2*r,y1+1*r,r);
		circle(x1+2*r,y1+3*r,r);

		y1+=4*r;
	}

}

int putbmp(int x, int y, char *s)
{
	FILE *fp;
	long begin, w, h;
	unsigned char k;
	unsigned char color[256], R, G, B;
	unsigned int i, j, bit;
	if ((fp = fopen(s, "rb")) == NULL)
	{
		printf("not open");
		return 1;
	}
	fseek(fp, 10l, 0);
	fread(&begin, 4, 1, fp);
	fseek(fp, 18l, 0);
	fread(&w, 4, 1, fp);
	fread(&h, 4, 1, fp);
	fseek(fp, 28l, 0);
	fread(&bit, 2, 1, fp);
	if (bit != 8)
	{
		fclose(fp);
		printf("bit:%d,not 8", bit);
		return 2;
	}
	fseek(fp, 54l, 0);
	for (i = 0; i < 256; i++)
	{
		fread(&B, 1, 1, fp);
		fread(&G, 1, 1, fp);
		fread(&R, 1, 1, fp);
		if (R < 42)
		{

			color[i] = (B > 84) + 2 * (G > 84);
		}
		else if (R < 126)
		{
			color[i] = 8 + (B > 168) + 2 * (G > 168);
		}
		else if (R < 210)
		{
			color[i] = 4 + (B > 84) + 2 * (G > 60);
		}
		else
		{
			color[i] = 12 + (B > 168) + 2 * (G > 168);
		}

		fseek(fp, 1, 1);
	}
	for (i = 0; i < h; i++)
	{

		fseek(fp, begin + (w + 3) / 4 * i * 4, 0);

		for (j = 0; j < w; j++)
		{

			fread(&k, 1, 1, fp);
			putpixel(x + j, y + h - i - 1, color[k]);
		}
	}
	fclose(fp);
	return 0;
}


void fruit_to_chip(int i,int type,fruits *fruit,chips *chip)
{
	chip[i].type = type;
	fruit[i].state = 0;
	chip[i].state = 1;
	chip[i].x = fruit[i].x;
	chip[i].y = fruit[i].y;
	chip[i].dx = fruit[i].dx;
	chip[i].dy = fruit[i].dy;
	chip[i].dv=fruit[i].dv;
}

void show_score(int i,fruits *fruit)
{
	char score[5];
	char score_show[5]="+";

	itoa(fruit[i].score,score,10);
	strcat(score_show,score);
	setfillstyle(SOLID_FILL,BLACK);
	bar(570,60,640,125);
	settextstyle(3,0,2);
	outtextxy(590,90,score_show);
}

void show_pomegrante_score(int cut)
{
	char cuts[6];

	setfillstyle(SOLID_FILL,BLACK);
	bar(570,60,640,125);
	itoa(cut,cuts,10);
	setcolor(LIGHTMAGENTA);
	settextstyle(3,0,2);
	if(cut<=3 && cut>0)
	{
		strcat(cuts,":+5");
		outtextxy(580,90,cuts);
	}
	else if(cut>3)
	{
		strcat(cuts,":+20");
		outtextxy(580,90,cuts);
	}
}
