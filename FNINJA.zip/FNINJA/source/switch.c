#include "./include/common.h"
#include "./include/main.h"


void switch_page_mode_1()
{
    int i;
    cleardevice();
    setbkcolor(BLUE);
    puthz(80, 75, "ˮ������", 48, 150, LIGHTGREEN);
    setcolor(WHITE);
    settextstyle(1, 0, 4);
    outtextxy(95, 180, "Happy Fruit,Merciless Ninja!");
    puthz(125, 260, "�������������У��������Ե�Ƭ�̡�����", 24, 24, 15);
    puthz(180, 360, "�ʶ���Ϸ�����ɽ�����", 24, 24, 15);
    setcolor(WHITE);
    settextstyle(1, 0, 3);
    outtextxy(185, 400, "Power By Wang & Feng");

    rectangle(100, 309, 530, 332);
    for (i = 0; i < 430; i++)
    {
        setfillstyle(2, BROWN);
        bar(100, 310, 100 + i, 330);
        if (i == 50) { show_pineapple(20, 30); }
        if (i == 100) { show_apple(100, 20); }
        if (i == 150) { show_lemon(180, 30); }
        if (i == 200) { show_pomegranate(260, 20); }
        if (i == 250) { show_banana(340, 30); }
        if (i == 300) { show_green_banana(420, 20); }
        if (i == 350) { show_grape(500, 30); }
        if (i == 400) { show_red_banana(580, 20); }

        delay(10);
    }
}
