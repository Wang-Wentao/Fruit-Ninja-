#include "./include/common.h"
#include "./include/main.h"
int counts_down(time_t start,long timelen)
{	
	time_t end;
	char diff[50];
	long interval,counts;
	
	end=time(NULL);
	interval=end-start;
	counts=timelen-interval;
	if(counts>0)
	{
		setfillstyle(SOLID_FILL,LIGHTGRAY);
		bar(570,390,650,440);
		itoa(counts,diff,10);
		setcolor(WHITE);
		settextstyle(SMALL_FONT, HORIZ_DIR, 8);
		outtextxy(585,405,diff);
	}

	return interval;
}

