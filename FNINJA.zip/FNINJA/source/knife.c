#include "./include/common.h"
#include "./include/main.h"


//���г�ʼ��
void Initialize_Knife(struct KNIFE* knife)  
{
	int i;
	for (i = 0; i < knife_len; i++)
	{
		knife[i].x0 = 0;
		knife[i].y0 = 0;
		knife[i].x1 = 0;
		knife[i].y1 = 0;
	}
}


//�����½ڵ�
void insert_knife(struct KNIFE* kf, struct KNIFE kf_temp, int* pos)
{
	assign_knife(kf + (*pos), &kf_temp);
	*pos = ((*pos) + 1) % knife_len; //posѭ���ƶ�
}

//���洫��
void assign_knife(struct KNIFE* kf, struct KNIFE* kf_temp)
{
	kf->x0 = kf_temp->x0;
	kf->y0 = kf_temp->y0;
	kf->x1 = kf_temp->x1;
	kf->y1 = kf_temp->y1;
	kf->state = kf_temp->state;
}

//�����ӡ
void print_knife(struct KNIFE* kf)
{
	int i;
	for (i = 0; i < knife_len; i++)
	{
		if ((kf + i)->state)
		{
			setcolor(GREEN);
			setlinestyle(0, 0, 3);
			line((kf + i)->x0, (kf + i)->y0, (kf + i)->x1, (kf + i)->y1);

		}
	}
}

//����״̬���
void clear_knife(struct KNIFE* kf)
{
	int i;
	for (i = 0; i < knife_len; i++)
	{
		kf[i].state = 0;
	}
		

}

//���ǵ��к�����ÿ��ˢ��ҳ��ʱʹ��
void cover_knife(struct KNIFE* knife)
{
	int i;
	for (i = 0; i < knife_len; i++)
	{
		setcolor(BLACK);
		setlinestyle(0, 0, 3);
		line((knife + i)->x0, (knife + i)->y0, (knife + i)->x1, (knife + i)->y1);
	}
	
}
