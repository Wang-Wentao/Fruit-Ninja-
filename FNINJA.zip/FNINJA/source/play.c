#include "./include/common.h"
#include "./include/main.h"

int fruit_init(fruits *fruit,int d)	//ˮ����ʼλ�� 
{
	int i,n;
	int count_b=0;
	srand((unsigned)time(NULL));
		
	n=rand()%2+3;	
	
	for(i=0;i<n;i++)
	{
		fruit[i].type=rand()%16+1;
		
		if(fruit[i].type==9 && i==0) 
		{
			n=1;
			fruit[i].state=1;
			fruit[i].x=rand()%350+70;
			fruit[i].y=490;		
			fruit[i].dx=0;
			fruit[i].dy=v0; 
			fruit[i].score=5;
			fruit[i].dv=g;
			break;
		}
		else if(fruit[i].type==9 && i!=0)
		{
			n--;
			continue;
		}
		
		if(fruit[i].type>=12 && fruit[i].type<=14 && count_b==0)
			count_b++;
		else if(fruit[i].type>=12 && fruit[i].type<=14 && count_b!=0)
		{
			n--;
			continue;
		}
		
		fruit[i].state=1;
		if(fruit[i].type==15 || fruit[i].type==16)
			fruit[i].x=rand()%180+140;
		else
			fruit[i].x=rand()%350+70;
		fruit[i].y=490;
		fruit[i].score=5;
		fruit[i].dv=g;			
		switch(d)
		{
			case 0:
				fruit[i].dx=rand()%11-5;
				break;
			case 1:
				fruit[i].dx=rand()%21-10;
				break;
			case 2:
				fruit[i].dx=rand()%31-15;
				break;
		}
		fruit[i].dy=v0;
	}

	return n;
}

int fruit_init_red(fruits *fruit,int d)	//ˮ����ʼλ�ã��е����㽶�� 
{
	int i,n;

	srand((unsigned)time(NULL));
		
	n=rand()%4+4;	
	
	for(i=0;i<n;i++)
	{
		fruit[i].type=rand()%16+1;	
		if((fruit[i].type>=12 && fruit[i].type<=14)||fruit[i].type==9||fruit[i].type==15||fruit[i].type==16)
			fruit[i].type=10;
		
		fruit[i].state=1;
		fruit[i].x=rand()%350+70;
		fruit[i].y=490;
		fruit[i].score=5;	
		fruit[i].dv=g;			
		switch(d)
		{
			case 0:
				fruit[i].dx=rand()%11-5;
				break;
			case 1:
				fruit[i].dx=rand()%21-10;
				break;
			case 2:
				fruit[i].dx=rand()%31-15;
				break;
		}
		fruit[i].dy=v0;
	}

	return n;
}

int fruit_init_blue(fruits *fruit,int d)	//ˮ����ʼλ�ã��е����㽶�� 
{
	int i,n;

	srand((unsigned)time(NULL));

	n=rand()%2+3;	
	
	for(i=0;i<n;i++)
	{
		fruit[i].type=rand()%16+1;
		
		if(fruit[i].type==9 && i==0) 
		{
			n=1;
			fruit[i].state=1;
			fruit[i].x=rand()%350+70;
			fruit[i].y=490;		
			fruit[i].dx=0;
			fruit[i].dy=vs; 
			fruit[i].score=5;
			fruit[i].dv=gs;							
			break;
		}
		else if(fruit[i].type==9 && i!=0)
		{
			n--;
			continue;
		}
		
		if(fruit[i].type>=12 && fruit[i].type<=14)
			fruit[i].type=10;
		fruit[i].score=5;		
		fruit[i].state=1;
		if(fruit[i].type==15 || fruit[i].type==16)
			fruit[i].x=rand()%180+140;
		else
			fruit[i].x=rand()%350+70;
		fruit[i].y=490;
		switch(d)
		{
			case 0:
				fruit[i].dx=rand()%11-5;
				break;
			case 1:
				fruit[i].dx=rand()%21-10;
				break;
			case 2:
				fruit[i].dx=rand()%31-15;
				break;
		}
		fruit[i].dy=vs;
		fruit[i].dv=gs;			
	}

	return n;
}

int fruit_init_green(fruits *fruit,int d)	//ˮ����ʼλ��(�е����㽶�� 
{
	int i,n;
	
	srand((unsigned)time(NULL));
		
	n=rand()%2+3;	
	
	for(i=0;i<n;i++)
	{
		fruit[i].type=rand()%16+1;
		
		if(fruit[i].type==9 && i==0) 
		{
			n=1;
			fruit[i].state=1;
			fruit[i].x=rand()%350+70;
			fruit[i].y=490;		
			fruit[i].dx=0;
			fruit[i].dy=v0; 
			fruit[i].score=10;
			fruit[i].dv=g;			
			break;
		}
		else if(fruit[i].type==9 && i!=0)
		{
			n--;
			continue;
		}
		
		if(fruit[i].type>=12 && fruit[i].type<=14)
			fruit[i].type=10;
		
		fruit[i].state=1;
		if(fruit[i].type==15 || fruit[i].type==16)
			fruit[i].x=rand()%180+140;
		else
			fruit[i].x=rand()%350+70;
		fruit[i].y=490;
		fruit[i].score=10;	
		fruit[i].dv=g;		
		switch(d)
		{
			case 0:
				fruit[i].dx=rand()%11-5;
				break;
			case 1:
				fruit[i].dx=rand()%21-10;
				break;
			case 2:
				fruit[i].dx=rand()%31-15;
				break;
		}
		fruit[i].dy=v0;
	}

	return n;
}

void show_fruit_classic(fruits* fruit,int n,int* miss,int* shut_down_flag)	//����ˮ����ǰλ�� 
{
	int i;
//	int count = 0;	//��������ʯ��ĸ��� 
//	int count_b = 0;	//�������������㽶�ĸ��� 

	for (i = 0; i < n; i++)
	{

		if (fruit[i].y <= 490 && fruit[i].state == 1 )
		{
			if (fruit[i].type == 1 || fruit[i].type == 2) show_apple(fruit[i].x, fruit[i].y);
			else if (fruit[i].type == 3 || fruit[i].type == 4) show_pineapple(fruit[i].x, fruit[i].y);
			else if (fruit[i].type == 5 || fruit[i].type == 6) show_lemon(fruit[i].x, fruit[i].y);
			else if (fruit[i].type == 7 || fruit[i].type == 8) show_grape(fruit[i].x, fruit[i].y);
			else if (fruit[i].type == 9 ) { show_pomegranate(fruit[i].x, fruit[i].y);}
			else if (fruit[i].type == 10 || fruit[i].type == 11) show_banana(fruit[i].x, fruit[i].y);
			else if (fruit[i].type == 12 ) { show_red_banana(fruit[i].x, fruit[i].y); }
			else if (fruit[i].type == 13 ) { show_blue_banana(fruit[i].x, fruit[i].y);  }
			else if (fruit[i].type == 14 ) { show_green_banana(fruit[i].x, fruit[i].y);  }
			else if (fruit[i].type == 15 || fruit[i].type == 16) show_bomb(fruit[i].x, fruit[i].y);

		}
		else
		{
			if (fruit[i].state == 1 && fruit[i].type !=15 && fruit[i].type !=16)
			{
				(*miss)++;
				if ((*miss) >= 10)
				{
					*shut_down_flag = 1;
				}
			}
			fruit[i].state = 0;
		}
	}

}

void show_fruit_chan(fruits* fruit, int n)	//����ˮ����ǰλ�� 
{
	int i;
	//	int count = 0;	//��������ʯ��ĸ��� 
	//	int count_b = 0;	//�������������㽶�ĸ��� 

	for (i = 0; i < n; i++)
	{

		if (fruit[i].y <= 490 && fruit[i].state == 1)
		{
			if (fruit[i].type == 1 || fruit[i].type == 2) show_apple(fruit[i].x, fruit[i].y);
			else if (fruit[i].type == 3 || fruit[i].type == 4) show_pineapple(fruit[i].x, fruit[i].y);
			else if (fruit[i].type == 5 || fruit[i].type == 6) show_lemon(fruit[i].x, fruit[i].y);
			else if (fruit[i].type == 7 || fruit[i].type == 8) show_grape(fruit[i].x, fruit[i].y);
			else if (fruit[i].type == 9) { show_pomegranate(fruit[i].x, fruit[i].y); }
			else if (fruit[i].type == 10 || fruit[i].type == 11) show_banana(fruit[i].x, fruit[i].y);
			else if (fruit[i].type == 12) { show_red_banana(fruit[i].x, fruit[i].y); }
			else if (fruit[i].type == 13) { show_blue_banana(fruit[i].x, fruit[i].y); }
			else if (fruit[i].type == 14) { show_green_banana(fruit[i].x, fruit[i].y); }
			else if (fruit[i].type == 15 || fruit[i].type == 16) show_bomb(fruit[i].x, fruit[i].y);

		}
		else
		{
			fruit[i].state = 0;
		}
	}

}

void cover_fruit(fruits *fruit,int i)	//�ڸ���һ֡��ˮ�� 
{
	if (fruit[i].type == 1 || fruit[i].type == 2) cover_apple(fruit[i].x, fruit[i].y);
	if (fruit[i].type == 3 || fruit[i].type == 4) cover_pineapple(fruit[i].x, fruit[i].y);
	if (fruit[i].type == 5 || fruit[i].type == 6) cover_lemon(fruit[i].x, fruit[i].y);
	if (fruit[i].type == 7 || fruit[i].type == 8) cover_grape(fruit[i].x, fruit[i].y);
	if (fruit[i].type == 9) cover_pomegranate(fruit[i].x, fruit[i].y);
	if (fruit[i].type == 10 || fruit[i].type == 11) cover_banana(fruit[i].x, fruit[i].y);
	if (fruit[i].type == 12) cover_banana(fruit[i].x, fruit[i].y);
	if (fruit[i].type == 13) cover_banana(fruit[i].x, fruit[i].y);
	if (fruit[i].type == 14) cover_banana(fruit[i].x, fruit[i].y);
	if (fruit[i].type == 15 || fruit[i].type == 16) cover_bomb(fruit[i].x, fruit[i].y);
} 

void update_fruit(fruits* fruit, int t , int n)	//����ˮ��λ�� 
{
	int i;
		
	for (i = 0; i < n; i++)
	{	
		cover_fruit(fruit,i);
		if(fruit[i].type) 
			fruit[i].y -= fruit[i].dy;
		if(fabs(fruit[i].dv-g)<0.1)
			fruit[i].dy = v0- fruit[i].dv * t;
		else
			fruit[i].dy=vs- fruit[i].dv * t;
		fruit[i].x += fruit[i].dx;
		if (fruit[i].x >= 465 || fruit[i].x < 60)
			fruit[i].dx= -fruit[i].dx;
		if((fruit[i].type==15 || fruit[i].type==16) && (fruit[i].x>=415 || fruit[i].x<110))
			fruit[i].dx= -fruit[i].dx;
	}
}

void throw_fruit_classic(fruits* fruit, int *t , int *n,chips* chip,int d,int* miss,int* shut_down_flag,int *special,int *round)	//�׳�ˮ�� 
{
	int i, m , cnt; //m������¼���ڷǻ�Ծ״̬��ˮ������,cnt������¼�Ƿ���ˮ����м��״̬Ϊ1
	int d_t; 
	m = 0,cnt=0;
	
	show_fruit_classic(fruit ,*n,miss, shut_down_flag);
	d_t = 30 / (*n);
	delay(d_t);
	update_fruit(fruit, *t , *n); 		
	(*t)++;

	for (i = 0; i < *n; i++)
	{
		if (fruit[i].state == 0)
			m++;
		if (chip[i].state == 1)
			cnt++;
	}

	if (m == *n && cnt == 0)
	{
		setfillstyle(SOLID_FILL,BLACK);
		bar(30,100,545,480);
		bar(570,60,640,125);
		if((*special==0))
			*n = fruit_init(fruit,d);
		else if((*special==1))
			{*n = fruit_init_red(fruit,d);(*round)++;}
		else if((*special==2))
			{*n = fruit_init_blue(fruit,d);(*round)++;}
		else if((*special==3))
			{*n = fruit_init_green(fruit,d);(*round)++;}	
		if((*round)==4)
		{
			(*round)=0;
			(*special)=0;			
		}			
		*t = 0;
	}

}

void throw_fruit_chan(fruits* fruit, int* t, int* n, chips* chip, int d,int *round,int *special)	//�׳�ˮ�� 
{
	int i, m, cnt; //m������¼���ڷǻ�Ծ״̬��ˮ������,cnt������¼�Ƿ���ˮ����м��״̬Ϊ1
	int d_t;
	m = 0, cnt = 0;

	show_fruit_chan(fruit, *n);
	d_t = 30 / (*n);
	delay(d_t);
	update_fruit(fruit, *t, *n);
	(*t)++;

	for (i = 0; i < *n; i++)
	{
		if (fruit[i].state == 0)
			m++;
		if (chip[i].state == 1)
			cnt++;
	}

	if (m == *n && cnt == 0)
	{
		setfillstyle(SOLID_FILL,BLACK);
		bar(30,100,545,480); 
		bar(570,60,640,125);
		if((*special==0))
			*n = fruit_init(fruit,d);
		else if((*special==1))
			{*n = fruit_init_red(fruit,d);(*round)++;}
		else if((*special==2))
			{*n = fruit_init_blue(fruit,d);(*round)++;}
		else if((*special==3))
			{*n = fruit_init_green(fruit,d);(*round)++;}	
		if((*round)==4)
		{
			(*round)=0;
			(*special)=0;
		}		
		*t = 0;
	}

}

void Initialize_Chips(chips* chip)  //��Ƭ��ʼ��
{
	int i;
	for (i = 0; i < chip_len; i++)
	{
		chip[i].dx = 0;
		chip[i].dy = 0;
		chip[i].state = 0;
		chip[i].type = 0;
		chip[i].x = 0;
		chip[i].y = 0;
	}
}

void show_chips(chips* chip, int n)	//����ˮ����Ƭ��ǰλ�� 
{
	int i;
	
	for (i = 0; i < n; i++)
	{

		if (chip[i].y <= 490 && chip[i].state == 1)
		{
			if (chip[i].type == 1 || chip[i].type == 2) show_apple_pieces(chip[i].x, chip[i].y);
			if (chip[i].type == 3 || chip[i].type == 4) show_pineapple_pieces(chip[i].x, chip[i].y);
			if (chip[i].type == 5 || chip[i].type == 6) show_lemon_pieces(chip[i].x, chip[i].y);
			if (chip[i].type == 7 || chip[i].type == 8) show_grape_pieces(chip[i].x, chip[i].y);
			if (chip[i].type == 9 ){show_pomegranate_pieces(chip[i].x, chip[i].y);}
			if (chip[i].type == 10 || chip[i].type == 11) show_banana_pieces(chip[i].x, chip[i].y);
			if (chip[i].type == 12 ){show_red_banana_pieces(chip[i].x, chip[i].y);}
			if (chip[i].type == 13 ){show_blue_banana_pieces(chip[i].x, chip[i].y);}
			if (chip[i].type == 14 ){show_green_banana_pieces(chip[i].x, chip[i].y);}
			if (chip[i].type == 15 || chip[i].type == 16) {show_bomb_pieces(chip[i].x, chip[i].y);}
		}
		else
			chip[i].state = 0;

	}

}

void cover_chips(chips* chip, int i)	//�ڸ���һ֡��ˮ����Ƭ
{
	if (chip[i].state == 1)
	{
		if (chip[i].type == 1 || chip[i].type == 2) cover_apple_pieces(chip[i].x, chip[i].y);
		if (chip[i].type == 3 || chip[i].type == 4) cover_pineapple_pieces(chip[i].x, chip[i].y);
		if (chip[i].type == 5 || chip[i].type == 6) cover_lemon_pieces(chip[i].x, chip[i].y);
		if (chip[i].type == 7 || chip[i].type == 8) cover_grape_pieces(chip[i].x, chip[i].y);
		if (chip[i].type == 9) cover_pomegranate_pieces(chip[i].x, chip[i].y);
		if (chip[i].type == 10 || chip[i].type == 11) cover_banana_pieces(chip[i].x, chip[i].y);
		if (chip[i].type == 12) cover_banana_pieces(chip[i].x, chip[i].y);
		if (chip[i].type == 13) cover_banana_pieces(chip[i].x, chip[i].y);
		if (chip[i].type == 14) cover_banana_pieces(chip[i].x, chip[i].y);
		if (chip[i].type == 15 || chip[i].type == 16) cover_bomb_pieces(chip[i].x, chip[i].y);
	}
	
}

void update_chips(chips* chip, int t, int n)	//����ˮ����Ƭλ�� 
{
	int i;

	for (i = 0; i < n; i++)
	{
		cover_chips(chip, i);
		if (chip[i].type)
			chip[i].y -= chip[i].dy;
		if(fabs(chip[i].dv-g)<0.1)
			chip[i].dy = v0 - chip[i].dv*t;
		else
			chip[i].dy = vs - chip[i].dv*t;
		chip[i].x += chip[i].dx;
		if (chip[i].x >= 465 || chip[i].x < 60)
			chip[i].dx = -chip[i].dx;
		if((chip[i].type==15 || chip[i].type==16) && (chip[i].x>=415 || chip[i].x<110))
			chip[i].dx= -chip[i].dx;
	}
}

void throw_chips(chips* chip, int* t, int* n) //ˮ����Ƭ�ƶ�
{
	update_chips(chip, *t, *n);
	show_chips(chip, *n);
}
/*����ģʽ�µ����и�ͼƷ�*/
void Fruit_Game_Knife_Classic(int* nx, int* ny, int* nbuttons, struct KNIFE* knife, int* pos, fruits* fruit, int n, chips* chip , int* score,int* shut_down_flag,int *special,int *cut)
{
	struct KNIFE knife_temp;
	int i;
	int knife_flag;	
	int x0 = *nx, y0 = *ny;
	union REGS regs;

	regs.x.ax = 3;
	int86(0x33, &regs, &regs); //�����굱ǰλ�� 
	*nbuttons = regs.x.bx;
	*nx = regs.x.cx;
	*ny = regs.x.dx;

	if (*nbuttons == 1) //�����갴��
	{
		knife_temp.x0 = x0;
		knife_temp.y0 = y0;
		knife_temp.x1 = *nx;
		knife_temp.y1 = *ny;
		knife_temp.state = 1; //״̬����Ϊ��Ծ״̬
		knife_flag = 1;
		insert_knife(knife, knife_temp, pos);
		print_knife(knife);
		detact_cut_classic(*nx, *ny, fruit, n, chip,score, shut_down_flag,special,cut);
	}

	else if (*nbuttons == 0 && knife_flag == 1) //�������ɿ�
	{
		knife_flag = 0;
		clear_knife(knife);
		*pos = 0;
	}	
}

/*��ģʽ�µ����и�ͼƷ�*/
void Fruit_Game_Knife_Chan(int* nx, int* ny, int* nbuttons, struct KNIFE* knife, int* pos, fruits* fruit, int n, chips* chip, int* score,int *special,int *cut)
{
	struct KNIFE knife_temp;	
	int knife_flag;
	int x0 = *nx, y0 = *ny;
	int i=0;
	union REGS regs;

	regs.x.ax = 3;
	int86(0x33, &regs, &regs); //�����굱ǰλ�� 
	*nbuttons = regs.x.bx;
	*nx = regs.x.cx;
	*ny = regs.x.dx;

	if (*nbuttons == 1) //�����갴��
	{
		knife_temp.x0 = x0;
		knife_temp.y0 = y0;
		knife_temp.x1 = *nx;
		knife_temp.y1 = *ny;
		knife_temp.state = 1; //״̬����Ϊ��Ծ״̬
		knife_flag = 1;
		insert_knife(knife, knife_temp, pos);
		print_knife(knife);
		detact_cut_chan(*nx, *ny, fruit, n, chip, score,special,cut);
		for(i=0;i<n;i++)
		{
			if(fruit[i].state == 0)
			{
	
			}
		}			
	}	

	else if (*nbuttons == 0 && knife_flag == 1) //�������ɿ�
	{
		knife_flag = 0;
		clear_knife(knife);
		*pos = 0;
	}

}

/*����ģʽ�µ������м��ӷ�*/
void detact_cut_classic(int x, int y, fruits* fruit, int n, chips* chip , int* score,int* shut_down_flag,int *special,int *cut) //����ģʽ�¼���Ƿ��е�ˮ�����Ʒ�
{
	int i;
	
	for (i = 0; i < n; i++)
	{
		if (fruit[i].state == 1)  //���ˮ���ǻ�Ծ״̬
		{
			switch (fruit[i].type)
			{
			case 1:
				if (x > fruit[i].x - 20 && x<fruit[i].x + 20 && y>fruit[i].y - 23 && y < fruit[i].y + 20)
				{
					cover_apple(x, y);
					fruit_to_chip(i,1,fruit,chip);
					setcolor(LIGHTRED);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 2:
				if (x > fruit[i].x - 20 && x<fruit[i].x + 20 && y>fruit[i].y - 23 && y < fruit[i].y + 20)
				{
					cover_apple(x, y);
					fruit_to_chip(i,2,fruit,chip);
					setcolor(LIGHTRED);
					show_score(i,fruit);					
					(*score) += fruit[i].score;
				}

				break;

			case 3:
				if (x > fruit[i].x - 12 && x<fruit[i].x + 12 && y>fruit[i].y - 7 && y < fruit[i].y + 30)
				{
					cover_pineapple(x, y);
					fruit_to_chip(i,3,fruit,chip);
					setcolor(YELLOW);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 4:
				if (x > fruit[i].x - 12 && x<fruit[i].x + 12 && y>fruit[i].y - 7 && y < fruit[i].y + 30)
				{
					cover_pineapple(x, y);
					fruit_to_chip(i,4,fruit,chip);
					setcolor(YELLOW);
					show_score(i,fruit);	
					(*score) += fruit[i].score;
				}

				break;

			case 5:
				if (x > fruit[i].x - 20 && x<fruit[i].x + 20 && y>fruit[i].y - 15 && y < fruit[i].y + 15)
				{
					cover_lemon(x, y);
					fruit_to_chip(i,5,fruit,chip);
					setcolor(YELLOW);
					show_score(i,fruit);	
					(*score) += fruit[i].score;
				}

				break;

			case 6:
				if (x > fruit[i].x - 20 && x<fruit[i].x + 20 && y>fruit[i].y - 15 && y < fruit[i].y + 15)
				{
					cover_lemon(x, y);
					fruit_to_chip(i,6,fruit,chip);
					setcolor(YELLOW);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 7:
				if (x > fruit[i].x - 8 && x<fruit[i].x + 8 && y>fruit[i].y - 8 && y < fruit[i].y + 8)
				{
					cover_grape(x, y);
					fruit_to_chip(i,7,fruit,chip);
					setcolor(CYAN);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 8:
				if (x > fruit[i].x - 15 && x<fruit[i].x + 15 && y>fruit[i].y - 15 && y < fruit[i].y + 15)
				{
					cover_grape(x, y);
					fruit_to_chip(i,8,fruit,chip);
					setcolor(CYAN);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 9:
				if (x > fruit[i].x - 12 && x<fruit[i].x + 16 && y>fruit[i].y - 14 && y < fruit[i].y + 24)
				{
					show_pomegrante_score(*cut);
					if((*cut<=3))
					{
						(*score)+=5;
						(*cut)++;
					
					}
					else
					{
						cover_pomegranate(x,y);
						fruit_to_chip(i,9,fruit,chip);
						(*score) += 20;  //��������ʯ�����Ч
						(*cut)=0;
					}
					
				}

				break;

			case 10:
				if (x > fruit[i].x - 5 && x<fruit[i].x + 34 && y>fruit[i].y - 8 && y < fruit[i].y + 34)
				{
					cover_banana(x, y);
					fruit_to_chip(i,10,fruit,chip);
					setcolor(YELLOW);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 11:
				if (x > fruit[i].x - 5 && x<fruit[i].x + 34 && y>fruit[i].y - 8 && y < fruit[i].y + 34)
				{
					cover_banana(x, y);
					fruit_to_chip(i,11,fruit,chip);
					setcolor(YELLOW);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 12:
				if (x > fruit[i].x - 5 && x<fruit[i].x + 34 && y>fruit[i].y - 8 && y < fruit[i].y + 34)
				{
					cover_banana(x, y);
					fruit_to_chip(i,12,fruit,chip);
					setcolor(LIGHTRED);
					show_score(i,fruit);
					(*score) += fruit[i].score;
					(*special)=1;
				}

				break;

			case 13:
				if (x > fruit[i].x - 5 && x<fruit[i].x + 34 && y>fruit[i].y - 8 && y < fruit[i].y + 34)
				{
					cover_banana(x, y);
					fruit_to_chip(i,13,fruit,chip);
					setcolor(LIGHTBLUE);
					show_score(i,fruit);
					(*score) += fruit[i].score;
					(*special)=2;
				}

				break;

			case 14:
				if (x > fruit[i].x - 5 && x<fruit[i].x + 34 && y>fruit[i].y - 8 && y < fruit[i].y + 34)
				{
					cover_banana(x, y);
					fruit_to_chip(i,14,fruit,chip);
					setcolor(LIGHTGREEN);
					show_score(i,fruit);
					(*score) += fruit[i].score;
					(*special)=3;
				}

				break;

			case 15:
				if (x > fruit[i].x - 16 && x<fruit[i].x + 16 && y>fruit[i].y - 27 && y < fruit[i].y + 16)
				{
					cover_bomb(x, y);
					fruit_to_chip(i,15,fruit,chip);
					if((*special)==3)
					{
						(*score)-=60;		
					}
					else
						(*score) -= 30;
					*shut_down_flag = 1;

					if ((*score) < 0)
						(*score) = 0;
					bar(30,100,545,480); 	
					show_bomb_pieces(chip[i].x,chip[i].y);	
				}

				break;

			case 16:
				if (x > fruit[i].x - 16 && x<fruit[i].x + 16 && y>fruit[i].y - 27 && y < fruit[i].y + 16)
				{
					cover_bomb(x, y);
					fruit_to_chip(i,16,fruit,chip);
					if((*special)==3)
						(*score)-=60;
					else
						(*score) -= 30;
						
					*shut_down_flag = 1;

					if ((*score) < 0)
						(*score) = 0;
					bar(30,100,545,480); 	
					show_bomb_pieces(chip[i].x,chip[i].y);	
				}

				break;
			}
		}
		
	}
	/*�������С��0����ô�ͽ�������Ϊ0*/
	if ((*score) < 0) 
		(*score) = 0;
}

/*��ģʽ�µ������м��ӷ�*/
void detact_cut_chan(int x, int y, fruits* fruit, int n, chips* chip, int* score,int *special,int *cut) //����ģʽ�¼���Ƿ��е�ˮ�����Ʒ�
{
	int i;
	for (i = 0; i < n; i++)
	{
		if (fruit[i].state == 1)  //���ˮ���ǻ�Ծ״̬
		{
			switch (fruit[i].type)
			{
			case 1:
				if (x > fruit[i].x - 20 && x<fruit[i].x + 20 && y>fruit[i].y - 23 && y < fruit[i].y + 20)
				{
					cover_apple(x, y);
					fruit_to_chip(i,1,fruit,chip);
					setcolor(LIGHTRED);
					show_score(i,fruit);	
					(*score) += fruit[i].score;
				}

				break;

			case 2:
				if (x > fruit[i].x - 20 && x<fruit[i].x + 20 && y>fruit[i].y - 23 && y < fruit[i].y + 20)
				{
					cover_apple(x, y);
					fruit_to_chip(i,2,fruit,chip);
					setcolor(LIGHTRED);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 3:
				if (x > fruit[i].x - 12 && x<fruit[i].x + 12 && y>fruit[i].y - 7 && y < fruit[i].y + 30)
				{
					cover_pineapple(x, y);
					fruit_to_chip(i,3,fruit,chip);
					setcolor(YELLOW);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 4:
				if (x > fruit[i].x - 12 && x<fruit[i].x + 12 && y>fruit[i].y - 7 && y < fruit[i].y + 30)
				{
					cover_pineapple(x, y);
					fruit_to_chip(i,4,fruit,chip);
					setcolor(YELLOW);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 5:
				if (x > fruit[i].x - 20 && x<fruit[i].x + 20 && y>fruit[i].y - 15 && y < fruit[i].y + 15)
				{
					cover_lemon(x, y);
					fruit_to_chip(i,5,fruit,chip);
					setcolor(YELLOW);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 6:
				if (x > fruit[i].x - 20 && x<fruit[i].x + 20 && y>fruit[i].y - 15 && y < fruit[i].y + 15)
				{
					cover_lemon(x, y);
					fruit_to_chip(i,6,fruit,chip);
					setcolor(YELLOW);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 7:
				if (x > fruit[i].x - 15 && x<fruit[i].x + 15 && y>fruit[i].y - 15 && y < fruit[i].y + 15)
				{
					cover_grape(x, y);
					fruit_to_chip(i,7,fruit,chip);
					setcolor(CYAN);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 8:
				if (x > fruit[i].x - 15 && x<fruit[i].x + 15 && y>fruit[i].y - 15 && y < fruit[i].y + 15)
				{
					cover_grape(x, y);
					fruit_to_chip(i,8,fruit,chip);
					setcolor(CYAN);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 9:
				if (x > fruit[i].x - 12 && x<fruit[i].x + 16 && y>fruit[i].y - 14 && y < fruit[i].y + 24)
				{
					show_pomegrante_score(*cut);
					if((*cut<=3))
					{
						(*score)+=5;
						(*cut)++;
					}
					else
					{
						cover_pomegranate(x,y);
						fruit_to_chip(i,9,fruit,chip);
						(*score) += 20;  //��������ʯ�����Ч
						(*cut)=0;
					}		
				}

				break;

			case 10:
				if (x > fruit[i].x - 5 && x<fruit[i].x + 34 && y>fruit[i].y - 8 && y < fruit[i].y + 34)
				{
					cover_banana(x, y);
					fruit_to_chip(i,10,fruit,chip);
					setcolor(YELLOW);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 11:
				if (x > fruit[i].x - 5 && x<fruit[i].x + 34 && y>fruit[i].y - 8 && y < fruit[i].y + 34)
				{
					cover_banana(x, y);
					fruit_to_chip(i,11,fruit,chip);
					setcolor(YELLOW);
					show_score(i,fruit);
					(*score) += fruit[i].score;
				}

				break;

			case 12:
				if (x > fruit[i].x - 5 && x<fruit[i].x + 34 && y>fruit[i].y - 8 && y < fruit[i].y + 34)
				{
					cover_banana(x, y);
					fruit_to_chip(i,12,fruit,chip);
					setcolor(LIGHTRED);
					show_score(i,fruit);
					(*score) += fruit[i].score;
					(*special)=1;
				}

				break;

			case 13:
				if (x > fruit[i].x - 5 && x<fruit[i].x + 34 && y>fruit[i].y - 8 && y < fruit[i].y + 34)
				{
					cover_banana(x, y);
					fruit_to_chip(i,13,fruit,chip);
					setcolor(LIGHTBLUE);
					show_score(i,fruit);	
					(*score) += fruit[i].score;
					(*special)=2;				
				}

				break;

			case 14:
				if (x > fruit[i].x - 5 && x<fruit[i].x + 34 && y>fruit[i].y - 8 && y < fruit[i].y + 34)
				{
					cover_banana(x, y);
					fruit_to_chip(i,14,fruit,chip);
					setcolor(LIGHTGREEN);
					show_score(i,fruit);
					(*score) += fruit[i].score;
					(*special)=3;					
				}

				break;

			case 15:
				if (x > fruit[i].x - 16 && x<fruit[i].x + 16 && y>fruit[i].y - 27 && y < fruit[i].y + 16)
				{
					cover_bomb(x, y);
					fruit_to_chip(i,15,fruit,chip);
					setfillstyle(SOLID_FILL,BLACK);
					bar(570,60,640,125);
					setcolor(WHITE);
					if((*special)==3)
					{
						(*score)-=60;
						settextstyle(3,0,2);
						outtextxy(590,80,"-60");
					}
					else
					{
						(*score)-=30;
						settextstyle(3,0,2);
						outtextxy(590,80,"-30");
					}
						
					if ((*score) < 0)
						(*score) = 0;
				}

				break;

			case 16:
				if (x > fruit[i].x - 16 && x<fruit[i].x + 16 && y>fruit[i].y - 27 && y < fruit[i].y + 16)
				{
					cover_bomb(x, y);
					fruit_to_chip(i,16,fruit,chip);
					setfillstyle(SOLID_FILL,BLACK);
					bar(570,60,640,125);
					setcolor(WHITE);
					if((*special)==3)
					{
						(*score)-=60;
						settextstyle(3,0,2);
						outtextxy(590,80,"-60");
					}
					else
					{
						(*score)-=30;
						settextstyle(3,0,2);
						outtextxy(590,80,"-30");
					}
						
					if ((*score) < 0)
						(*score) = 0;
				}

				break;
			}
		}
	}
	/*�������С��0����ô�ͽ�������Ϊ0*/
	if ((*score) < 0)
		(*score) = 0;
}

/*����ģʽ������ʧ�������ӡ*/
void show_message_classic(int* classic_score,int* miss,int* flag)
{
	char a[10][2] = { "0","1","2","3","4","5","6","7","8","9" };
	int hundred, ten, one, hundred_1, ten_1, one_1;

	hundred = (*classic_score) / 100;
	ten = ((*classic_score) - hundred * 100) / 10;
	one = (*classic_score) % 10;

	hundred_1 = (*miss) / 100;
	ten_1 = ((*miss) - hundred_1 * 100) / 10;
	one_1 = (*miss) % 10;

	setfillstyle(SOLID_FILL, LIGHTGRAY);
	bar(550, 400, 650, 440);
	puthz(555, 405, "ʧ��", 16, 20, WHITE);
	settextstyle(SMALL_FONT, HORIZ_DIR, 6);
	setcolor(WHITE);
	outtextxy(610, 415, a[hundred_1]);
	outtextxy(620, 415, a[ten_1]);
	outtextxy(630, 415, a[one_1]);

	setfillstyle(SOLID_FILL, LIGHTGREEN);
	bar(550, 20, 650, 60);
	puthz(555, 25, "����", 16, 20, WHITE);
	settextstyle(SMALL_FONT, HORIZ_DIR, 6);
	setcolor(WHITE);
	outtextxy(610, 32, a[hundred]);
	outtextxy(620, 32, a[ten]);
	outtextxy(630, 32, a[one]);
	
	if ((*classic_score) >= Success_Score)
	{
		*flag = 1;
	}
}

/*��ģʽ������ʧ�������ӡ*/
void show_message_chan(int* classic_score)
{
	char a[10][2] = { "0","1","2","3","4","5","6","7","8","9" };
	int hundred, ten, one;

	hundred = (*classic_score) / 100;
	ten = ((*classic_score) - hundred * 100) / 10;
	one = (*classic_score) % 10;

	setfillstyle(SOLID_FILL, LIGHTGREEN);
	bar(550, 20, 650, 60);
	puthz(555, 25, "����", 16, 20, WHITE);
	settextstyle(SMALL_FONT, HORIZ_DIR, 6);
	setcolor(WHITE);
	outtextxy(610, 32, a[hundred]);
	outtextxy(620, 32, a[ten]);
	outtextxy(630, 32, a[one]);
}

