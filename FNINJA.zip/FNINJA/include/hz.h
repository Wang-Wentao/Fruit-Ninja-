#ifndef __HZ_H__
#define __HZ_H__

void puthz(int x, int y,char *s,int flag,int part,int color);
#endif

