#ifndef _PAGE_HELP_H
#define _PAGE_HELP_H

int page_help(void);
void page_help_screen(void);
int page_help_handbook(void);
void page_help_handbook_screen(void);
void page_help_handbook_items(void);

extern int MouseX, MouseY, press;
#endif
