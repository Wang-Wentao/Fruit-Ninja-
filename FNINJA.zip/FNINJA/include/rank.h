#ifndef _PAGE_RANKING_LIST_H
#define _PAGE_RANKING_LIST_H

#define  Path_of_File  ".\\s_n\\NAME.DAT"

int page_ranking_list(void);
void page_ranking_list_screen(void);
int	page_ranking_list_mode_1(void);
int page_ranking_list_mode_2(void);
void page_ranking_list_mode_1_screen(void);
void page_ranking_list_mode_2_screen(void); 
void Rank_List_Init(void);
void Get_All_Scores(char name[3][20], int* score); //��ȡ��ǰ���а���������ҵķ���

extern int MouseX, MouseY, press;

#endif
