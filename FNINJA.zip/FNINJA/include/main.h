#ifndef _MAIN_H_
#define _MAIN_H_

#include "mouse1.h"
#include "switch.h" 
#include "game.h"
#include "help.h"
#include "rank.h"
#include "set.h"
#include "hz.h" 
#include "graph.h"
#include "file.h"
#include "knife.h"
#include "play.h"
#include "time1.h"

void main(void);
int menu(char* id);
void menu_screen(void);
void start_page(void);
void Game_Name_Input(char* id);
extern int MouseX, MouseY, press;
#endif
