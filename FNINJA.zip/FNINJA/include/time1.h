#ifndef __TIME_H
#define __TIME_H

int counts_down(time_t start,long timelen);

#endif
