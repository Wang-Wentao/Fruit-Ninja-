#ifndef _PAGE_SWITCH_H
#define _PAGE_SWITCH_H

void switch_page_mode_1(void);

extern int MouseX, MouseY, press;
#endif
