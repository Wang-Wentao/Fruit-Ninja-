#ifndef _COMMON_H_
#define _COMMON_H_

#include<graphics.h>
#include<stdio.h>
#include<stdlib.h>
#include<bios.h>
#include<dos.h>
#include<conio.h>
#include<time.h>
#include<math.h> 
#include<string.h>

extern int MouseX, MouseY, press;

#endif
