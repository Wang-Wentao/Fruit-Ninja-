#ifndef _PAGE_SETTING_H
#define _PAGE_SETTING_H

int page_setting(int *d,int *ti);
void page_setting_screen(void);

extern int MouseX, MouseY, press;
#endif
