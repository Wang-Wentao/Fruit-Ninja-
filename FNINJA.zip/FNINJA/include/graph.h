#ifndef __GRAPH_H
#define __GRAPH_H


void show_apple(int xd,int yd);
void show_pineapple(int xd,int yd);
void show_lemon(int xd,int yd);
void show_grape(int xd,int yd);
void show_pomegranate(int xd,int yd);
void show_banana(int xd,int yd);
void show_blue_banana(int xd,int yd);
void show_red_banana(int xd,int yd);
void show_green_banana(int xd,int yd);
void show_bomb(int xd,int yd);

void show_apple_pieces(int xd,int yd);
void show_banana_pieces(int xd,int yd);
void show_red_banana_pieces(int xd,int yd);
void show_blue_banana_pieces(int xd,int yd);
void show_green_banana_pieces(int xd,int yd);
void show_grape_pieces(int xd,int yd);
void show_pineapple_pieces(int xd,int yd);
void show_pomegranate_pieces(int xd,int yd);
void show_lemon_pieces(int xd, int yd);
void show_bomb_pieces(int xd, int yd); //ը����Ƭ

void cover_apple(int xd,int yd);
void cover_banana(int xd,int yd);
void cover_grape(int xd,int yd);
void cover_lemon(int xd,int yd);
void cover_pineapple(int xd,int yd);
void cover_pomegranate(int xd,int yd);
void cover_bomb(int xd,int yd);

void cover_apple_pieces(int xd,int yd);
void cover_banana_pieces(int xd,int yd);
void cover_grape_pieces(int xd,int  yd);
void cover_pineapple_pieces(int xd,int yd);
void cover_pomegranate_pieces(int xd,int yd);
void cover_lemon_pieces(int xd,int yd);
void cover_bomb_pieces(int xd,int yd);

void draw_hori_circles(int x, int y, int x_end, int color);
void draw_verti_circles(int x, int y,int color); 

int putbmp(int x, int y, char *s);


#endif
